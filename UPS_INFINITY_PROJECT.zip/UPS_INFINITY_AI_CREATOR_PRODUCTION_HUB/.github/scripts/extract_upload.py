#!/usr/bin/env python3
"""Safely extract the UPS INFINITY upload ZIP into the repository root."""
from pathlib import Path, PurePosixPath
import shutil
import stat
import tempfile
import zipfile

REPO = Path.cwd().resolve()
ARCHIVE = REPO / "UPS_INFINITY_PROJECT.zip"
EXPECTED_ROOT = "UPS_INFINITY_AI_CREATOR_PRODUCTION_HUB"

if not ARCHIVE.is_file():
    raise SystemExit("ERROR: UPS_INFINITY_PROJECT.zip was not found at repository root.")

with zipfile.ZipFile(ARCHIVE) as zf:
    infos = zf.infolist()
    if not infos:
        raise SystemExit("ERROR: ZIP archive is empty.")

    # Reject absolute paths, traversal paths, and symbolic links.
    for info in infos:
        name = info.filename.replace("\\", "/")
        path = PurePosixPath(name)
        if path.is_absolute() or ".." in path.parts or not path.parts:
            raise SystemExit(f"ERROR: Unsafe ZIP path: {info.filename}")
        mode = (info.external_attr >> 16) & 0xFFFF
        if stat.S_ISLNK(mode):
            raise SystemExit(f"ERROR: Symbolic links are not allowed: {info.filename}")

    roots = {PurePosixPath(i.filename.replace("\\", "/")).parts[0] for i in infos}
    if roots != {EXPECTED_ROOT}:
        raise SystemExit(
            "ERROR: ZIP must contain exactly one top-level folder named "
            f"{EXPECTED_ROOT}. Found: {sorted(roots)}"
        )

    with tempfile.TemporaryDirectory(prefix="ups-infinity-extract-") as temp:
        temp_path = Path(temp)
        zf.extractall(temp_path)
        source = temp_path / EXPECTED_ROOT
        if not source.is_dir():
            raise SystemExit("ERROR: Expected project folder is missing after extraction.")

        # Merge the project contents into repository root, retaining the
        # original frontend/backend/docs/config folder structure.
        for item in source.iterdir():
            target = REPO / item.name
            if item.is_dir():
                shutil.copytree(item, target, dirs_exist_ok=True)
            else:
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(item, target)

ARCHIVE.unlink()
print("SUCCESS: UPS INFINITY project extracted. Original folder structure preserved.")
